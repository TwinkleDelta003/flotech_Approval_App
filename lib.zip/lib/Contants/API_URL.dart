// http://192.168.5.104/DeltaContractorManagement/api/Contractor/API_InsertContractor

String BASE_URL = "http://103.228.146.54:81/DeltaiERPMobileApp/";

// ! Main Forms URL
String lOGIN = BASE_URL + "API/API_VerifyMobileNo.aspx";
String vERIFY_OTP = BASE_URL + "API/API_VerifyOTP.aspx";
String rESEND_OTP = BASE_URL + "API/API_ResendOTP.aspx";

String pendingCount = BASE_URL + "API/API_PendingPOCount.aspx";
String poDoneCount = BASE_URL + "API/API_DonePOCount.aspx";

String SO_PENDING_COUNT = BASE_URL + "API/API_PendingSOCount.aspx";
String SO_TOTAL_COUNT = BASE_URL + "API/API_DoneSOCount.aspx";

String RC_PENDING_COUNT = BASE_URL + "API/API_PendingRCCount.aspx";
String RC_TOTAL_COUNT = BASE_URL + "API/API_DoneRCCount.aspx";

String PO_PENDING_DETAIL_LIST =
    BASE_URL + "API/API_PendingPODetailList.aspx"; // not use
String PO_TOTAL__DETAIL_LIST =
    BASE_URL + "API/API_DonePODetailList.aspx"; // not use

String SO_PENDING_DETAIL_LIST = BASE_URL + "API/API_PendingSODetailList.aspx";
String SO_TOTAL__DETAIL_LIST = BASE_URL + "API/API_DoneSODetailList.aspx";

String RC_PENDING_DETAIL_LIST = BASE_URL + "API/API_PendingRCDetailList.aspx";
String RC_TOTAL__DETAIL_LIST = BASE_URL + "API/API_DoneRCDetailList.aspx";

String PO_APPROVAL_STATUS = BASE_URL + "API/API_UpdateApprovalStausPO.aspx";

String RC_APPROVAL_STATUS = BASE_URL + "API/API_UpdateApprovalStausRC.aspx";

String SO_APPROVAL_STATUS = BASE_URL + "API/API_UpdateApprovalStausSO.aspx";

String disPOCountURL = BASE_URL + "API/API_DisapprovedPOCount.aspx";
String disPOListURL = BASE_URL + "API/API_DisapprovedPOList.aspx";
