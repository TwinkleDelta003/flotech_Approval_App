class Constants {
  static const String isLogin = 'isLogin';
  static const String mobile = 'mobile';
  static const String fcmId = 'fcmId';
  static const String userName = 'userName';
  static const String firstName = 'firstName';
  static const String lastName = 'lastName';
  static const String userId = 'userId';
  static const String empId = 'empId';
  static const String pass = 'pass';
  static const String email = 'email';
  static const String empShow = 'empShow';
  static const String prfPic = 'prfPic';
  static const String divTextId = 'divTextId';
  static const String isAdmin = 'isAdmin';
}
