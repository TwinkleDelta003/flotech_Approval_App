import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:unnati/Screen/POPendingScreen.dart';

class NotificationAPI {
// todo ---------- End of Firebase API -------------------------
  static final plugin = FlutterLocalNotificationsPlugin();

  // static final channel = AndroidNotificationChannel('id', 'title'
  //     description: "Description of the notification",
  //     playSound: true,
  //     importance: Importance.high);

  // Future<void> requestNotificationPermissionForIOS() async {
  //   if (await Permission.notification.request().isGranted) {
  //     // Permission is already granted.
  //     return;
  //   }

  //   // Request the permission if not granted.
  //   var status = await Permission.notification.request();
  //   if (status.isGranted) {
  //     // Permission granted. Handle your notification logic here.
  //     print("Notification permission granted.");
  //   } else if (status.isDenied) {
  //     print("Notification permission denied.");
  //   } else if (status.isPermanentlyDenied) {
  //     print("Notification permission permanently denied. Open settings?");
  //     // You can show a dialog to inform the user and direct them to the app settings.
  //     openAppSettings();
  //   }
  // }

  static final channel = AndroidNotificationChannel(
      "default_notification_channel_id", "name",
      description: "", playSound: true, importance: Importance.high);

  static Future<void> _firebaseMessagingBackgroundhandler(
      RemoteMessage message) async {
    print("A Background Message was received: ${message.messageType}");
  }

  static Future<void> backgroundMessage() async {
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundhandler);

    if (Platform.isAndroid) {
      await plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          .createNotificationChannel(channel);
      print("This is Android");
    } else if (Platform.isIOS) {
      print("This is IOS");
    }

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
            alert: true, badge: true, sound: true);
  }

  static Future<void> initilizeNotification() async {
    if (Platform.isAndroid) {
      var initialzationSettingsAndroid =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      var initializationSettings =
          InitializationSettings(android: initialzationSettingsAndroid);
      plugin.initialize(initializationSettings);
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        RemoteNotification notification = message.notification;
        AndroidNotification androidNotification = message.notification.android;
        if (notification != null && androidNotification != null) {
          // print('Notification Title: ${notification.title}');

          // print('Notification Body: ${notification.body}');
          plugin.show(
              notification.hashCode,
              notification.title,
              notification.body,
              NotificationDetails(
                  android: AndroidNotificationDetails(
                channel.id,
                channel.name,
                channelDescription: channel.description,
                playSound: true,
                icon: '@mipmap/ic_launcher',
                color: Colors.blue,
              )));
        }
      });

      // ! Android Code is Here
    } else if (Platform.isIOS) {
      // ! IOS code is here
    }
  }
}

class PushNotificationService {
  // It is assumed that all messages contain a data field with the key 'type'
  Future<void> setupInteractedMessage() async {
    await Firebase.initializeApp();
    // Get any messages which caused the application to open from a terminated state.
    // If you want to handle a notification click when the app is terminated, you can use `getInitialMessage`
    // to get the initial message, and depending in the remoteMessage, you can decide to handle the click
    // This function can be called from anywhere in your app, there is an example in main file.
    // RemoteMessage initialMessage =
    //     await FirebaseMessaging.instance.getInitialMessage();
    // If the message also contains a data property with a "type" of "chat",
    // navigate to a chat screen
    // if (initialMessage != null && initialMessage.data['type'] == 'chat') {
    // Navigator.pushNamed(context, '/chat',
    //     arguments: ChatArguments(initialMessage));
    // }
    // Also handle any interaction when the app is in the background via a
    // Stream listener
    // This function is called when the app is in the background and user clicks on the notification
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      if (message.notification.title == 'PO Created') {
        // Handle chat-related action
        // For example, navigate to a chat screen

        Get.to(() => POPendingApprovalSCreen(po: message.notification.body));
        print(message.notification.body);
      } else {
        Get.to(() => POPendingApprovalSCreen(po: message.notification.body));
        print(message.notification.body);

        // Handle other action
        // For example, navigate to a different screen
      }
    });
    await enableIOSNotifications();
    await registerNotificationListeners();
  }

  registerNotificationListeners() async {
    AndroidNotificationChannel channel = androidNotificationChannel();
    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
        FlutterLocalNotificationsPlugin();
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    var androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    var iOSSettings = DarwinInitializationSettings(
      requestSoundPermission: false,
      requestBadgePermission: false,
      requestAlertPermission: false,
    );
    var initSetttings =
        InitializationSettings(android: androidSettings, iOS: iOSSettings);
    flutterLocalNotificationsPlugin.initialize(initSetttings,
        onDidReceiveNotificationResponse: (message) async {});

    // todo this code for if notification get when app is opened
// onMessage is called when the app is in foreground and a notification is received
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification notification = message.notification;
      AndroidNotification android = message.notification?.android;
// If `onMessage` is triggered with a notification, construct our own
      // local notification to show to users using the created channel.
      if (notification != null && android != null) {
        flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(channel.id, channel.name,
                channelDescription: channel.description,
                icon: android.smallIcon,
                playSound: true),
          ),
        );
      }
    });
  }

  enableIOSNotifications() async {
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true, //! Required to display a heads up notification
      badge: true,
      sound: true,
    );
  }

  androidNotificationChannel() => AndroidNotificationChannel(
        'high_importance_channel',
        'High Importance Notifications',
        description: "",
        importance: Importance.max,
      );
}
